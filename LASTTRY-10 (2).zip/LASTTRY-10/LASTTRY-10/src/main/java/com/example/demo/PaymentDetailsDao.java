package com.example.demo;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("Pdao")
public class PaymentDetailsDao {
	HibernateTemplate ht;

	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	
	@Transactional
	public PaymentDetails createPaymentDetails(PaymentDetails paymentDetails)
	{
		ht.save(paymentDetails);
		return paymentDetails;
	}
	public List<PaymentDetails> read()
	{
		return ht.loadAll(PaymentDetails.class);
	}
	
	public PaymentDetails readPaymentDetails(String categoryId)
	{
		return ht.get(PaymentDetails.class, categoryId);
	}
	public List<PaymentDetails>  paidOrders(String paymentStatus,String tailorId)
	{
		Session session = ht.getSessionFactory().openSession();
		Query query = session.createQuery("SELECT p FROM PaymentDetails  p where p.paymentStatus=? and p.tailorId=?");
		query.setParameter(0, paymentStatus);
		query.setParameter(1, tailorId);
		
		List<PaymentDetails> list=query.getResultList();
		return list;
		
	}
	
	@Transactional
	public void updatePaymentDetails(PaymentDetails paymentDetails) {
		ht.update(paymentDetails);
	}
	
	@Transactional
	public void deletePaymentDetails(PaymentDetails paymentDetails)
	{
		ht.delete(paymentDetails);
	}


}