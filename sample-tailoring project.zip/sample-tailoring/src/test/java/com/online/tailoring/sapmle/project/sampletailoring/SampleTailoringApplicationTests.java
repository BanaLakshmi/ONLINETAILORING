package com.online.tailoring.sapmle.project.sampletailoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleTailoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
