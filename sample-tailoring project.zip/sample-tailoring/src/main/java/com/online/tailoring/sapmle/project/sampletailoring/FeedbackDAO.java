package com.online.tailoring.sapmle.project.sampletailoring;
import java.util.ArrayList;
import java.util.List;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;




@Component("feedback")
public class FeedbackDAO {
	
	HibernateTemplate ht; 


	public HibernateTemplate getHt() {
		return ht;
	}
	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	@Transactional
	public void create(Feedback feeedback)
	{
		ht.save(feeedback);
	}
	
	@Transactional
	public void saveFeedback(Feedback  feedback){  
	                  ht.save(feedback);  
	} 
	@Transactional
	public void updateFeedback(Feedback feedback){  
		 ht.update(feedback);  
	}  
	@Transactional
	public void delete(Feedback feedback){  
		 ht.delete(feedback);  
	}  
	public Feedback getById(int id){  
		Feedback feedback=(Feedback) ht.get(Feedback.class,id);  
		return feedback ;
	}  
	public List<Feedback> getFeedback(){  
		List<Feedback> list=new ArrayList<Feedback>();  
		list= ht.loadAll(Feedback.class);  
		return list;  
	}  

}
