package com.online.tailoring.sapmle.project.sampletailoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleTailoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleTailoringApplication.class, args);
	}

}
