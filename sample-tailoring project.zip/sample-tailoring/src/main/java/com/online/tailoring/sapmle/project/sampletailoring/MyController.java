package com.online.tailoring.sapmle.project.sampletailoring;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	
	private static final Feedback Feedback = null;

	public ModelAndView home()
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		FeedbackDAO feedback=(FeedbackDAO) ctx.getBean("feedback");
		List<Feedback> feedbacks = feedback.getFeedback();
		System.out.println(feedbacks.size());
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		mv.addObject("feedbacks",feedbacks);
		return mv;
	}
	
	@RequestMapping("/add")
	public ModelAndView add(Feedback feedback)
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		FeedbackDAO feedback1=(FeedbackDAO) ctx.getBean("feedback");
		feedback1.getFeedback();
		return home();
	}
}
