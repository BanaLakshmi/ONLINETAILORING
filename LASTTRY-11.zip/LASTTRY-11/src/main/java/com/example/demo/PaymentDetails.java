
package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="paymentDetails")
public class PaymentDetails {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int paymentDetailsId;
	private Integer orderId;
	private String userId;
	private String tailorId;
	private String paymentStatus;
	
	public String getTailorId() {
		return tailorId;
	}



	public void setTailorId(String tailorId) {
		this.tailorId = tailorId;
	}



	public PaymentDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public String getPaymentStatus() {
		return paymentStatus;
	}



	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}



	public int getPaymentDetailsId() {
		return paymentDetailsId;
	}
	public void setPaymentDetailsId(int paymentDetailsId) {
		this.paymentDetailsId = paymentDetailsId;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	

}

