package com.example.demo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Help {
	@Id
	@Column(name = "requestId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long requestId;

	private String issue;
	private String description;
	private Date dateOfTicket;

	public Help() {
		super();
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDateOfTicket() {
		return dateOfTicket;
	}

	public void setDateOfTicket(Date dateOfTicket) {
		this.dateOfTicket = dateOfTicket;
	}

	public Help(Long requestId, String issue, String description, Date dateOfTicket) {
		super();
		this.requestId = requestId;
		this.issue = issue;
		this.description = description;
		this.dateOfTicket = dateOfTicket;
	}

}