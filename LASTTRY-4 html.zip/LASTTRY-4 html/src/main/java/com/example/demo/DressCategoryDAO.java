package com.example.demo;
import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("Ddao")
public class DressCategoryDAO {
HibernateTemplate ht;

	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	
	@Transactional
	public DressCategory createDressCategory(DressCategory dressCategory)
	{
		ht.save(dressCategory);
		return dressCategory;
	}
	public List<DressCategory> read()
	{
		return ht.loadAll(DressCategory.class);
	}
	
	public DressCategory readDressCategory(String categoryId)
	{
		return ht.get(DressCategory.class, categoryId);
	}
	
	@Transactional
	public void updateDressCategory(DressCategory dressCategory) {
		ht.update(dressCategory);
	}
	
	@Transactional
	public void deleteDressCategory(DressCategory dressCategory)
	{
		ht.delete(dressCategory);
	}

	
	
}

